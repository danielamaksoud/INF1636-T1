import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class choosefile implements ActionListener {

	Component c;
	
	public choosefile(Component x)
	{
		c = x;
	}
	
	public void actionPerformed(ActionEvent e)
	{
	    JFileChooser abrir = new JFileChooser();  
	    abrir.showOpenDialog(null); 
	}
	
}
